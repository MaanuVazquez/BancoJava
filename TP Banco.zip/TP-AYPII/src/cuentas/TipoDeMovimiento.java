package cuentas;

public enum TipoDeMovimiento {

	CREDITO,
	DEBITO;
	
}
