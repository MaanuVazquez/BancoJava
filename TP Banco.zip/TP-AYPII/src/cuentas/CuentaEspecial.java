package cuentas;

public class CuentaEspecial extends Cuenta{
	
	public CuentaEspecial(){
		super();
	}
}
